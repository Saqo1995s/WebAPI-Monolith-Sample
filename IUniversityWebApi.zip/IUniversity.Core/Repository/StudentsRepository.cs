﻿using IUniversity.Common.Models;
using IUniversity.Core.Repository.Base;
using IUniversity.Core.Repository.Interface;

namespace IUniversity.Core.Repository
{
    public class StudentsRepository : BaseRepository<Student, CoreDbContext>, IStudentRepository
    {
        public StudentsRepository(CoreDbContext context) 
            : base(context)
        {
            //Add here your custom requests for "Student" entity using LINQ
        }
    }
}