﻿using System.IO;
using IUniversity.Common.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace IUniversity.Core
{
    public class CoreDbContext : DbContext
    {
        public CoreDbContext(DbContextOptions<CoreDbContext> options)
            : base(options)
        {
        }

        // Add a DbSet for each entity type that you want to include in your model. For more information 
        // on configuring and using a Code First model, see http://go.microsoft.com/fwlink/?LinkId=390109.

        #region DbSets

        public virtual DbSet<Student> Students { get; set; }
        
        //Creating and configuring database context
        #endregion

        #region DbContext Builder

        public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<CoreDbContext>
        {
            public CoreDbContext CreateDbContext(string[] args)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile(@Directory.GetCurrentDirectory() + "/../IUniversity.WebApi/appsettings.json")
                    .Build();
                var builder = new DbContextOptionsBuilder<CoreDbContext>();
                var connectionString = configuration.GetConnectionString("CoreDatabase");
                builder.UseSqlServer(connectionString);
                return new CoreDbContext(builder.Options);
            }
        }

        #endregion
    }
}
