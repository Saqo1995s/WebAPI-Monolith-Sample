﻿namespace IUniversity.Common.Constants
{
    public static class DatabaseConstants
    {
        public const string WebApiCoreDatabaseName = "CoreDatabase";
    }
}