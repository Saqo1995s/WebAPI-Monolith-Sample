﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace IUniversity.Common.Models
{
    public class Student
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, MaxLength(50, ErrorMessage = "exceeded the character limit for this column")]
        public string FirstName { get; set; }
        [Required, MaxLength(50, ErrorMessage = "exceeded the character limit for this column")]
        public string LastName { get; set; }
        [NotMapped, JsonIgnore]
        public string FullName => $"{FirstName} {LastName}";
        [Required, MaxLength(50, ErrorMessage = "exceeded the character limit for this column")]
        public string Group { get; set; }
    }
}
